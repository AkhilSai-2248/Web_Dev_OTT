from contextlib import nullcontext
from flask import Flask , render_template, request
from flask_mysqldb import MySQL

app =  Flask(__name__)
# configure
app.config['MYSQL_HOST']='localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'primevideo'

mysql = MySQL(app)

@app.route('/')
def home():
    return render_template('home.html')


@app.route('/login',methods=['GET','POST'])
def index():
    
    if request.method == 'POST':
        global cust_id
        ud = request.form
        
        cust_id = ud['cust_id'] 
        name = ud['name']
        addres = ud['addres']
        email = ud['email']
        mobile_no = ud['mobile_no']
        
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO `customer`(`cust_id`, `name`, `addres`, `email`, `mobile_no`) VALUES (%s,%s,%s,%s,%s)",(cust_id,name,addres,email,mobile_no))
        mysql.connection.commit()

        cur.close()
        return ' Login Sucess ',render_template('subs.html') 

    return render_template('register.html')    
        


@app.route('/subscription',methods=['GET','POST'])
def subs():
    if request.method == 'POST':
        sb = request.form

        subs_id = sb['subs_id']
        subs_typ = sb['subs_typ']
        subs_date = sb['subs_date']
        price = ['price']
        
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO `subscription`(`subs_id`, `subs_typ`, `subs_date`, `price`) VALUES (%s,%s,%s,%s)",(subs_id,subs_typ,subs_date,price))
        mysql.connection.commit()
        cur.close()
        return 'Congratulations',render_template('payments.html')
        
    return render_template('subs.html')

@app.route('/payments',methods=['GET','POST'])
def pay():
    
    if request.method == 'POST':
    
        pym = request.form
        paym_id = pym['payment_id']
        paym_typ = pym['payment_typ']
        paym_date = pym['payment_date']
        paym_due = nullcontext
        paym_amo = pym['amount_paid']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO `payment`(`payment_id`, `payment_typ`, `payment_date`, `due_date`, `amount_paid`) VALUES (%s,%s,%s,%s,%s)",(paym_id,paym_typ,paym_date,paym_due,paym_amo))       
        mysql.connection.commit()
        cur.close()
        return "<Payment Sucessful>", render_template('home.html')


    return render_template('payments.html')


@app.route('/movies')
def movies():
    cur = mysql.connection.cursor()
    movie1 = cur.execute("SELECT * FROM movies")
    if movie1>0:
        movie1 = cur.fetchall()
        return render_template('movie.html',movies=movie1)
    cur.close()    

@app.route('/payhis')
def payhis():
    cur = mysql.connection.cursor()
    pyh1 = cur.execute("SELECT * FROM payment_his")
    if pyh1>0:
        pyh1 = cur.fetchall()
        return render_template('payhis.html',payment_his=pyh1)

    cur.close()    


if __name__ == '__main__':
    
    app.run(debug=True)
